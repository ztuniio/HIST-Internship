<!DOCTYPE html>
<html>
	<head>
		<title>Div_And_Image</title>
	</head> 
        <body>
		
		<a href="../Links.php">Back</a>
	</body>
	<body>
	
		<h2>WWW Spider</h2>
		</div>
		<img src="image.jpg" width="300" height="300" />
		</div>

	</body>

</html>