<!DOCTYPE html>
<html>
<head>
	<title>Checkbox Form</title>
</head>
<body>
	<h2>Checkbox Form</h2>
	<form action="page2.php" method="POST">
		<label><input type="checkbox" name="stipend" value="1"> Stipend</label><br>
		<label><input type="checkbox" name="discipline" value="1"> Discipline</label><br>
		<label><input type="checkbox" name="attendance" value="1"> Attendance</label><br>
		<label><input type="checkbox" name="assignment" value="1"> Assignment</label><br>
		<label><input type="checkbox" name="agree" value="1"> Agree</label></br>

		<input type="submit" value="Submit">
	</form>
</body>
</html>
