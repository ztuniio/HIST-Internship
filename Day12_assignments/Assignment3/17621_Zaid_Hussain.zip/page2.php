<!DOCTYPE html>
<html>
<head>
	<title>Contact Info</title>
</head>
<body>
	<h2>Contact Info</h2>
	<form action="page3.php" method="GET">
		<label for="email">Email:</label>
		<input type="email" id="email" name="email" required></br>

		<label for="contact">Contact Number:</label>
		<input type="tel" id="contact" name="contact" required></br>

		<label for="address">Address:</label></br>
		<textarea id="address" name="address" rows="4" cols="50"></textarea></br>
		<input type="submit" value="Next">
	</form>
</body>
</html>
