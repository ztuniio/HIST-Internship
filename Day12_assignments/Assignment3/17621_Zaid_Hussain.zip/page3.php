<!DOCTYPE html>
<html>
<head>
	<title>Professional Info</title>
</head>
<body>
	<h2>Professional Info</h2>
	<form action="page4.php" method="GET">
		<label for="school">School Name:</label>
		<input type="text" id="school" name="school" required></br>

		<label for="college">College Name:</label>
		<input type="text" id="college" name="college" required></br>

		<label for="university">University Name:</label>
		<input type="text" id="university" name="university" required></br>

		
		
                <input type="submit" value="Submit">


</body>
</html>
