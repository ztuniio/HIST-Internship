<!DOCTYPE html>
<html>
<head>
	<title>Page 1</title>
</head>
<body>
	<h2>Page 1</h2>
	<form action="page2.php" method="post">
		<label>Number:</label>
		<input type="number" name="num_fields" min="1" max="10" required></br>
		<input type="submit" value="Submit">
	</form>
</body>
</html>
