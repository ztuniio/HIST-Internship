<html>
  <head>
    <title>Page1</title>
  </head>
  <body>
    <form action="Page2.php" method="post">
      Number of textfields: <input type="text" name="no_of_textfields"><br><br>
      <input type="submit" value="Submit">
    </form>
  </body>
</html>